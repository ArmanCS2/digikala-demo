<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="{{asset('app-assets/js/jquery-3.7.1.min.js')}}"></script>
<script src="{{asset('app-assets/js/popper.js')}}"></script>
<script src="{{asset('app-assets/js/bootstrap/bootstrap.min.js')}}"></script>
<script src="{{asset('app-assets/js/bootstrap/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('app-assets/plugins/owlcarousel/owl.carousel.min.js')}}"></script>
<script src="{{asset('app-assets/js/main.js')}}"></script>
<script src="{{asset('sweetalert/sweetalert2.min.js')}}"></script>
<script src="{{asset('sweetalert/sweetalert2.min.js')}}"></script>
<script src="{{asset('app-assets/fontawesome/js/all.js')}}"></script>
