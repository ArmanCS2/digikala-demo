<!-- jQuery -->
<script src="{{ asset('app-assets/js/jquery-3.7.1.min.js') }}"></script>

<!-- Bootstrap (Bundle includes Popper.js) -->
<script src="{{ asset('app-assets/js/bootstrap/bootstrap.bundle.min.js') }}"></script>

<!-- Owl Carousel -->
<script src="{{ asset('app-assets/plugins/owlcarousel/owl.carousel.min.js') }}"></script>

<!-- Main Script -->
<script src="{{ asset('app-assets/js/main.js') }}"></script>

<!-- SweetAlert -->
<script src="{{ asset('sweetalert/sweetalert2.min.js') }}" defer></script>

<!-- FontAwesome -->
<script src="{{ asset('app-assets/fontawesome/js/all.js') }}" defer></script>
