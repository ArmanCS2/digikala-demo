<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="author" content="butikala">
<meta name="description" content="{{\App\Models\Setting\Setting::first()->description}}">
<meta name="keywords" content="{{\App\Models\Setting\Setting::first()->keywords}}">

<link rel="icon" href="{{asset(str_replace('\\','/',\App\Models\Setting\Setting::first()->icon))}}">
<link rel="shortcut icon" href="{{asset(asset(str_replace('\\','/',\App\Models\Setting\Setting::first()->icon)))}}">

<link rel="stylesheet" href="{{ asset('app-assets/css/bootstrap/bootstrap-reboot.rtl.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/css/bootstrap/bootstrap.rtl.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/fontawesome/css/all.min.css') }}">
<title>فروشگاه بوتیکالا</title>
