<div>
    @if($showCreateForm)
        <livewire:product.create/>
    @else
        <livewire:product.index/>
    @endif
</div>
