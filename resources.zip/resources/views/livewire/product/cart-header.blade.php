<div>
    <span class="badge bg-danger text-white rounded-pill">{{$cartItemsCount->count()}}</span>
    <i class="fa fa-cart-shopping"></i>
</div>
