<div>
    <div class="row">
        <div class="col-md-4 offset-md-4">
            <livewire:task.notification />
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <livewire:task.create />
        </div>
        <div class="col-md-8">
            <livewire:task.index />
        </div>
    </div>

    <livewire:task.edit />
</div>
