<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="butikala">
<meta name="description" content="{{\App\Models\Setting\Setting::first()->description}}">
<meta name="keywords" content="{{\App\Models\Setting\Setting::first()->keywords}}">
<link rel="icon" href="{{asset(\App\Models\Setting\Setting::first()->icon)}}">
<link rel="shortcut icon" href="{{asset(\App\Models\Setting\Setting::first()->icon)}}">
<link rel="stylesheet" href="{{asset('admin-assets/css/bootstrap/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('admin-assets/fontawesome/css/all.css')}}">
<link rel="stylesheet" href="{{asset('admin-assets/css/animate.min.css')}}">
<link rel="stylesheet" href="{{asset('admin-assets/css/grid.css')}}">
<link rel="stylesheet" href="{{asset('admin-assets/select2/css/select2.min.css')}}">
<link rel="stylesheet" href="{{asset('sweetalert/sweetalert2.css')}}">
<link rel="stylesheet" href="{{asset('admin-assets/css/style.css')}}">

