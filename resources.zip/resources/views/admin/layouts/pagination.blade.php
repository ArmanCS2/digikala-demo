<section class="d-flex justify-content-center align-items-center text-center">
    {{$data->links('pagination::custom')}}
</section>
